<?php
defined('_JEXEC') or die;

class ModMemberDirectoryHelper 
{

    public static function validateSubscription($endpoint, $clientName, $clientEmail)
    {
        try {
            // Check the validity of the URL
            if (!filter_var($endpoint, FILTER_VALIDATE_URL)) {
                return [
                    'success' => false,
                    'message' => 'Invalid license validation URL.'
                ];
            }

            $siteUrl = JURI::base();

            $data = json_encode([
                'clientName' => $clientName,
                'clientEmail' => $clientEmail,
                'websiteIdentifier' => $siteUrl
            ]);

            // Initialize cURL with stricter parameters
            $ch = curl_init($endpoint);
            curl_setopt_array($ch, [
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => $data,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data),
                    'Accept: application/json',
                    'Ngrok-Skip-Browser-Warning: 1' 
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,  // Timeout of 10 seconds
                CURLOPT_CONNECTTIMEOUT => 5,  // Connection timeout of 5 seconds
                CURLOPT_SSL_VERIFYPEER => true,  // SSL certificate verification
                CURLOPT_SSL_VERIFYHOST => 2     // SSL hostname verification
            ]);

            // Execute the request
            $response = curl_exec($ch);
            
            // Handle cURL errors
            if ($response === false) {
                $curlError = curl_error($ch);
                curl_close($ch);
                return [
                    'success' => false,
                    'message' => 'Connection error: ' . $curlError
                ];
            }

            // Retrieve request information
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            // Decode the JSON response
            $responseData = json_decode($response, true);

            // Check JSON decoding
            if ($responseData === null) {
                return [
                    'success' => false,
                    'message' => 'Invalid or poorly formatted API response.'
                ];
            }

            // Normalize keys to avoid key_sensitive issues
            $responseData = array_change_key_case($responseData, CASE_LOWER);

            // Check the structure of the response
            if (!isset($responseData['success'])) {
                return [
                    'success' => false,
                    'message' => 'Incorrect API response. Missing success field.'
                ];
            }

            // Return the validation response   
            return $responseData;

        } catch (Exception $e) {
            // Handle generic exceptions
            return [
                'success' => false,
                'message' => 'Unexpected error: ' . $e->getMessage()
            ];
        }
    }

    public static function getUsersFromCustomQuery($sqlQuery)
    {
        $db = JFactory::getDbo();
        $db->setQuery($sqlQuery);
        $users = $db->loadObjectList(); 
        return $users;
    }
}
