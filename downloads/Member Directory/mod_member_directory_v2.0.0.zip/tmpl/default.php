<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_member_directory
 * 
 * This file is part of Member Directory Module.
 * 
 * Member Directory Module is a dual-licensed Joomla extension. The module's core 
 * functionality is released under GNU General Public License version 2 or later,
 * while the activation system and premium features are proprietary and require
 * a valid license key.
 *
 * @copyright   Copyright (C) 2025 Xcelerate. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *              The activation system and premium features are subject to additional
 *              terms. See LICENSE.txt for full license details.
 * @author      Xcelerate <contact@xcelerate-future.com>
 * @see         https://www.xcelerate-future.com for documentation and updates
 */

// Prevent direct access
defined('_JEXEC') or die;

// Load language files
JFactory::getLanguage()->load('mod_member_directory', JPATH_SITE.'/modules/mod_member_directory');

// Function to safely clean and decode text
function cleanText($text) {
    // Convert JSON-encoded strings to readable text
    $decodedText = json_decode('"' . $text . '"', true);
    return $decodedText !== null ? htmlspecialchars_decode($decodedText) 
    : htmlspecialchars_decode($text);
}

if (!empty($htmlContent)) {
    $decoded_html = cleanText($htmlContent);
    eval("?>$decoded_html");
} else {
    echo '<div class="error">Html content is empty</div>';
}


// Prepare translations for JavaScript
$translations = [
    'user' => JText::_('USER'),
    'users' => JText::_('USERS'),
    'searchPlaceholder' => JText::_('SEARCH_INPUT_PLACEHOLDER'),
    'notProvided' => JText::_('NOT_PROVIDED'),
    'notProvidedFemale' => JText::_('NOT_PROVIDED_FEMALE'),
    'notProvidedPlural' => JText::_('NOT_PROVIDED_PLURAL'),
    'notProvidedFemalePlural' => JText::_('NOT_PROVIDED_FEMALE_PLURAL')
];
// Pass translations to JavaScript
JFactory::getDocument()->addScriptDeclaration('const translations = ' . json_encode($translations) . ';');

if (!empty($jsContent)) {
    echo '<script>' . $jsContent . '</script>';
} else {
    echo '<div class="error">Js content is empty</div>';
}
?>