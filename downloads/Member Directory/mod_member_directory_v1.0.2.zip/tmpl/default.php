<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_member_directory
 * 
 * This file is part of Member Directory Module.
 * 
 * Member Directory Module is a dual-licensed Joomla extension. The module's core 
 * functionality is released under GNU General Public License version 2 or later,
 * while the activation system and premium features are proprietary and require
 * a valid license key.
 *
 * @copyright   Copyright (C) 2024 Xcelerate. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *              The activation system and premium features are subject to additional
 *              terms. See LICENSE.txt for full license details.
 * @author      Xcelerate <contact@xcelerate-future.com>
 * @see         https://cms-mod-fe.xcelerate-future.com for documentation and updates
 */

// Prevent direct access
defined('_JEXEC') or die;

// Load language files
JFactory::getLanguage()->load('mod_member_directory', JPATH_SITE.'/modules/mod_member_directory');

// Function to safely clean and decode text
function cleanText($text) {
    // Convert JSON-encoded strings to readable text
    $decodedText = json_decode('"' . $text . '"', true);
    return $decodedText !== null ? htmlspecialchars_decode($decodedText) 
    : htmlspecialchars_decode($text);
}

if (!empty($htmlContent)) {
    $decoded_html = cleanText($htmlContent);
    eval("?>$decoded_html");
} else {
    echo '<div class="error">Html content is empty</div>';
}

// Inject translations for JavaScript
$translations = [
    'user' => JText::_('USER'),
    'users' => JText::_('USERS')
];
echo '<script>';
echo 'const translations = ' . json_encode($translations, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) . ';';
echo '</script>';


if (!empty($jsContent)) {
   echo '<script>' . $jsContent . '</script>';
} else {
    echo '<div class="error">Js content is empty</div>';
}
?>
