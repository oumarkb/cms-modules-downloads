<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_member_directory
 * 
 * This file is part of Member Directory Module.
 * 
 * Member Directory Module is a dual-licensed Joomla extension. The module's core 
 * functionality is released under GNU General Public License version 2 or later,
 * while the activation system and premium features are proprietary and require
 * a valid license key.
 *
 * @copyright   Copyright (C) 2025 Xcelerate. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *              The activation system and premium features are subject to additional
 *              terms. See LICENSE.txt for full license details.
 * @author      Xcelerate <contact@xcelerate-future.com>
 * @see         https://www.xcelerate-future.com for documentation and updates
 */

// Prevent direct access
defined('_JEXEC') or die;

// Include the helper class for license validation
require_once dirname(__FILE__) . '/helper.php';

// Load CSS before license validation
JFactory::getDocument()->addStyleSheet(JURI::base() . 'modules/mod_member_directory/style.css');

// Retrieve module parameters
$params = $module->params instanceof JRegistry ? $module->params : new JRegistry($module->params);

$subscriptionKey = trim($params->get('subscription_key', ''));
$apiUrl = "https://cms-mod.xcelerate-future.com/api/subscriptions";
$validateSubscriptionEndpoint = $apiUrl . "/" . $subscriptionKey . "/validate";
$licensePurchaseUrl = "https://www.xcelerate-future.com/member-directory-module-license";
$clientName = trim($params->get('client_name', ''));
$clientEmail = trim($params->get('client_email', ''));

// Basic validation before calling the API
if (empty($subscriptionKey)) {
    echo '<div style="text-align: center;">
            <p class="error">License key is missing.</p> 
            <br><br>
            <a href="' . htmlspecialchars($licensePurchaseUrl, ENT_QUOTES, 'UTF-8') . '" 
               target="_blank" 
               class="btn btn-primary">
               Get a license key
            </a>
          </div>';
    return;
}
if (empty($clientName)) {
    echo '<div class="error">Client name is missing</div>';
    return;
}
if (empty($clientEmail)) {
    echo '<div class="error">Client email is missing.</div>';
    return;
}

// After license validation
$validationResult = ModMemberDirectoryHelper::validateSubscription($validateSubscriptionEndpoint, $clientName, $clientEmail);

if (!$validationResult['success']) {
    echo '<div class="error">' . htmlspecialchars($validationResult['message'], ENT_QUOTES, 'UTF-8') . '</div>';
    return;
}

// Retrieve contents from the API response
$moduleContent = $validationResult['subscription']['module'];

$htmlContent = $moduleContent['html'];

$cssContent = $moduleContent['css'];
$jsContent = $moduleContent['js'];
$sqlQuery = $moduleContent['sqlQuery'];

// Dynamically add CSS and JS if provided
if (!empty($cssContent)) {
    JFactory::getDocument()->addStyleDeclaration($cssContent);
}

// Fetch users data using potential custom SQL
$users = ModMemberDirectoryHelper::getUsersFromCustomQuery($sqlQuery);

// Load the template
require JModuleHelper::getLayoutPath('mod_member_directory', 'default');
