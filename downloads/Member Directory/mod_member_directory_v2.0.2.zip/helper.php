<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_member_directory
 * 
 * This file is part of Member Directory Module.
 * 
 * Member Directory Module is a dual-licensed Joomla extension. The module's core 
 * functionality is released under GNU General Public License version 2 or later,
 * while the activation system and premium features are proprietary and require
 * a valid license key.
 *
 * @copyright   Copyright (C) 2025 Xcelerate. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *              The activation system and premium features are subject to additional
 *              terms. See LICENSE.txt for full license details.
 * @author      Xcelerate <contact@xcelerate-future.com>
 * @see         https://www.xcelerate-future.com for documentation and updates
 */

defined('_JEXEC') or die;

class ModMemberDirectoryHelper 
{

    public static function validateSubscription($endpoint, $clientName, $clientEmail)
    {
        try {
            // Check the validity of the URL
            if (!filter_var($endpoint, FILTER_VALIDATE_URL)) {
                return [
                    'success' => false,
                    'message' => 'Invalid license validation URL.'
                ];
            }

            $siteUrl = JURI::base();

            $data = json_encode([
                'clientName' => $clientName,
                'clientEmail' => $clientEmail,
                'websiteIdentifier' => $siteUrl
            ]);

            // Initialize cURL with stricter parameters
            $ch = curl_init($endpoint);
            curl_setopt_array($ch, [
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => $data,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data),
                    'Accept: application/json',
                    'Ngrok-Skip-Browser-Warning: 1' 
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,  // Timeout of 10 seconds
                CURLOPT_CONNECTTIMEOUT => 5,  // Connection timeout of 5 seconds
                CURLOPT_SSL_VERIFYPEER => true,  // SSL certificate verification
                CURLOPT_SSL_VERIFYHOST => 2     // SSL hostname verification
            ]);

            // Execute the request
            $response = curl_exec($ch);
            
            // Handle cURL errors
            if ($response === false) {
                $curlError = curl_error($ch);
                curl_close($ch);
                return [
                    'success' => false,
                    'message' => 'Connection error: ' . $curlError
                ];
            }

            // Retrieve request information
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            // Decode the JSON response
            $responseData = json_decode($response, true);

            // Check JSON decoding
            if ($responseData === null) {
                return [
                    'success' => false,
                    'message' => 'Invalid or poorly formatted API response.'
                ];
            }

            // Normalize keys to avoid key_sensitive issues
            $responseData = array_change_key_case($responseData, CASE_LOWER);

            // Check the structure of the response
            if (!isset($responseData['success'])) {
                return [
                    'success' => false,
                    'message' => 'Incorrect API response. Missing success field.'
                ];
            }

            // Return the validation response   
            return $responseData;

        } catch (Exception $e) {
            // Handle generic exceptions
            return [
                'success' => false,
                'message' => 'Unexpected error: ' . $e->getMessage()
            ];
        }
    }

    public static function getUsersFromCustomQuery($params = null)
    {
        try {
            // Always build dynamic SQL query from params
            $db = JFactory::getDbo();
            $query = self::buildDynamicSqlQuery($params);
            $db->setQuery($query);
            return $db->loadObjectList();
        } catch (Exception $e) {
            JFactory::getApplication()->enqueueMessage(
                JText::_('Error loading users: ') . $e->getMessage(), 
                'error'
            );
            return array();
        }
    }
    
    /**
     * Builds a dynamic SQL query based on the module parameters
     *
     * @param   JRegistry  $params  The module parameters
     * @return  string     The SQL query
     */
    public static function buildDynamicSqlQuery($params)
    {
        $db = JFactory::getDbo();

        $query = "SELECT users.name AS Name, users.email AS email";

        $customFields = $params->get('custom_fields');
        if (!empty($customFields)) {
            foreach ($customFields as $field) {
                if ($field->field_name === 'email') {
                    continue;
                }
                if (!empty($field->profile_key) && !empty($field->field_name)) {
                    $sanitizedFieldName = preg_replace('/[^a-z0-9_]/i', '_', $field->field_name);
                    $profileKeyParts = explode('.', $field->profile_key);
                    $profileKeyLast = end($profileKeyParts);
                    $aliasName = 'profiles_' . $profileKeyLast;
                    
                    $query .= ", REPLACE({$aliasName}.profile_value, '\"', '') AS {$sanitizedFieldName}";
                }
            }
        }
        
        $query .= " FROM #__users AS users";
        
        // Add custom fields JOINs
        if (!empty($customFields)) {
            foreach ($customFields as $field) {
                if (!empty($field->profile_key)) {
                    $profileKeyParts = explode('.', $field->profile_key);
                    $profileKeyLast = end($profileKeyParts);
                    $aliasName = 'profiles_' . $profileKeyLast;
                    
                    $query .= " LEFT JOIN #__user_profiles AS {$aliasName} ON users.id = {$aliasName}.user_id AND {$aliasName}.profile_key = " . $db->quote($field->profile_key);
                }
            }
        }
        
        $query .= " ORDER BY users.name ASC";
        
        return $query;
    }
}
