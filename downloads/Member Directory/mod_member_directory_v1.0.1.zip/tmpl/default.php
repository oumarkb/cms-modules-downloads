<?php
// Prevent direct access
defined('_JEXEC') or die;

// Load language files
JFactory::getLanguage()->load('mod_member_directory', JPATH_SITE.'/modules/mod_member_directory');

// Function to safely clean and decode text
function cleanText($text) {
    // Convert JSON-encoded strings to readable text
    $decodedText = json_decode('"' . $text . '"', true);
    return $decodedText !== null ? htmlspecialchars_decode($decodedText) 
    : htmlspecialchars_decode($text);
}

if (!empty($htmlContent)) {
    $decoded_html = cleanText($htmlContent);
    eval("?>$decoded_html");
} else {
    echo '<div class="error">Html content is empty</div>';
}

// Inject translations for JavaScript
$translations = [
    'user' => JText::_('USER'),
    'users' => JText::_('USERS')
];
echo '<script>';
echo 'const translations = ' . json_encode($translations, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) . ';';
echo '</script>';


if (!empty($jsContent)) {
   echo '<script>' . $jsContent . '</script>';
} else {
    echo '<div class="error">Js content is empty</div>';
}
?>
